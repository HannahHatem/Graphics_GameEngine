# Default Mesh
./bin/GAME_APPLICATION -f=2 -c="config/mesh-test/default-0.jsonc"
./bin/GAME_APPLICATION -f=2 -c="config/mesh-test/default-1.jsonc"
./bin/GAME_APPLICATION -f=2 -c="config/mesh-test/default-2.jsonc"
./bin/GAME_APPLICATION -f=2 -c="config/mesh-test/default-3.jsonc"

# Monkey Mesh
./bin/GAME_APPLICATION -f=2 -c="config/mesh-test/monkey-0.jsonc"
./bin/GAME_APPLICATION -f=2 -c="config/mesh-test/monkey-1.jsonc"
./bin/GAME_APPLICATION -f=2 -c="config/mesh-test/monkey-2.jsonc"
./bin/GAME_APPLICATION -f=2 -c="config/mesh-test/monkey-3.jsonc"