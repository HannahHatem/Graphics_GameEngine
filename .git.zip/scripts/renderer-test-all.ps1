./bin/GAME_APPLICATION -f=2 -c="config/renderer-test/test-0.jsonc"
./bin/GAME_APPLICATION -f=2 -c="config/renderer-test/test-1.jsonc"