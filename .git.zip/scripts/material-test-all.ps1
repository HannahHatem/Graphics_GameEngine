./bin/GAME_APPLICATION -f=2 -c="config/material-test/test-0.jsonc"
./bin/GAME_APPLICATION -f=2 -c="config/material-test/test-1.jsonc"